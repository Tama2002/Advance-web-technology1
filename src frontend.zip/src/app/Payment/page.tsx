'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation'; // ✅ Import useRouter for redirection
import axios from 'axios';
import { TextInput, Button, Card, Label, Select } from 'flowbite-react';

export default function PaymentPage() {
  const router = useRouter(); // ✅ Initialize useRouter for navigation

  const [payment, setPayment] = useState({
    patientId: '', 
    patientName: '', 
    patientEmail: '', 
    amount: '',
    paymentMethod: '',
    paymentDate: '',
  });

  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // 🔹 Handle input changes
  const handleChange = (e) => {
    setPayment({ ...payment, [e.target.name]: e.target.value });
  };

  // 🔹 Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!payment.patientId || !payment.patientName || !payment.patientEmail || !payment.amount || !payment.paymentMethod || !payment.paymentDate) {
      alert('Please fill all required fields.');
      return;
    }

    try {
      const response = await axios.post('http://localhost:4002/payment/create', payment);
      setSuccessMessage(response.data.message);

      // ✅ Redirect to dashboard after 2 seconds
      setTimeout(() => {
        router.push('/Dashboard'); // ✅ Redirect to dashboard page
      }, 2000);

    } catch (error) {
      console.error('Payment failed:', error);
      setErrorMessage('Payment failed. Please try again.');
    }
  };

  return (
    <div className="p-8 bg-gray-50 min-h-screen flex justify-center items-center">
      <Card className="w-full max-w-lg p-6 shadow-lg">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">Process Payment</h1>

        {successMessage && <p className="text-green-600 text-sm mb-4">{successMessage}</p>}
        {errorMessage && <p className="text-red-600 text-sm mb-4">{errorMessage}</p>}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="patientId">Patient ID</Label>
            <TextInput id="patientId" name="patientId" value={payment.patientId} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="patientName">Patient Name</Label>
            <TextInput id="patientName" name="patientName" value={payment.patientName} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="patientEmail">Patient Email</Label>
            <TextInput id="patientEmail" name="patientEmail" type="email" value={payment.patientEmail} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="amount">Amount ($)</Label>
            <TextInput id="amount" name="amount" type="number" value={payment.amount} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="paymentMethod">Payment Method</Label>
            <Select id="paymentMethod" name="paymentMethod" value={payment.paymentMethod} onChange={handleChange} required>
              <option value="">Select Payment Method</option>
              <option value="Credit Card">Credit Card</option>
              <option value="Debit Card">Debit Card</option>
              <option value="Nagad">Nagad</option>
              <option value="Bkash">Bkash</option>
            </Select>
          </div>

          <div>
            <Label htmlFor="paymentDate">Payment Date</Label>
            <TextInput id="paymentDate" name="paymentDate" type="date" value={payment.paymentDate} onChange={handleChange} required />
          </div>

          <div className="flex justify-between">
            <Button type="button" onClick={() => window.history.back()} className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg">
              Back
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
              Submit Payment
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
