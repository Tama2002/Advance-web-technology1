'use client';
import React from "react";
import { Button, Card } from "flowbite-react";
import { FaPhone, FaEnvelope, FaArrowLeft } from "react-icons/fa";
 
export default function Contact() {
  return (
    <div className="flex flex-col justify-center items-center min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 px-4">
      <h2 className="text-4xl font-bold text-blue-700 text-center mb-4">Contact Us</h2>
      <p className="text-lg text-gray-600 text-center mb-8">
        Have questions? Feel free to reach out. We're here to help!
      </p>
 
      {/* Contact Info Section */}
      <Card className="w-full max-w-lg p-6 shadow-xl transform transition duration-300 hover:scale-105 text-center">
        <div className="space-y-6">
          <div className="flex items-center space-x-3 text-lg text-gray-700">
            <FaPhone className="text-blue-600 text-2xl" />
            <span className="font-medium">+8801756677888</span>
          </div>
          <div className="flex items-center space-x-3 text-lg text-gray-700">
            <FaEnvelope className="text-blue-600 text-2xl" />
            <span className="font-medium">tamasaha39@gmail.com</span>
          </div>
        </div>
      </Card>
 
      {/* Back Button */}
      <div className="w-full max-w-lg mt-6 flex justify-start">
        <Button href="./" gradientDuoTone="blackToBlue" size="lg" className="flex items-center">
          <FaArrowLeft className="mr-2" /> Back
        </Button>
      </div>
    </div>
  );
}
 