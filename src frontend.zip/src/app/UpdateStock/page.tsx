'use client';
import { useState, useEffect } from 'react';
import { Table, Button, TextInput, Card, Label, Select, Modal } from 'flowbite-react';
import axios from 'axios';

export default function InventoryManagement() {
  const [inventory, setInventory] = useState([]);
  const [search, setSearch] = useState('');
  const [selectedMedicine, setSelectedMedicine] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchInventory = async () => {
      try {
        const response = await axios.get('http://localhost:4002/inventory');
        setInventory(response.data.data);
      } catch (error) {
        console.error('Error fetching inventory:', error);
        alert('Failed to fetch inventory.');
      }
    };

    fetchInventory();
  }, []);

  const filteredInventory = inventory.filter(
    (item) =>
      item.medicineName.toLowerCase().includes(search.toLowerCase()) ||
      item.medicineId.toLowerCase().includes(search.toLowerCase())
  );

  const openEditModal = (medicine) => {
    setSelectedMedicine(medicine);
    setShowModal(true);
  };

  const handleInputChange = (e) => {
    setSelectedMedicine({ ...selectedMedicine, [e.target.name]: e.target.value });
  };

  const handleUpdate = async () => {
    setLoading(true);
    try {
      const response = await axios.put(
        `http://localhost:4002/inventory/update/${selectedMedicine.id}`,
        {
          medicineName: selectedMedicine.medicineName,
          medicineCategory: selectedMedicine.medicineCategory,
          quantityAvailable: selectedMedicine.quantityAvailable,
        }
      );

      if (response.data) {
        setInventory((prevInventory) =>
          prevInventory.map((item) => (item.id === selectedMedicine.id ? selectedMedicine : item))
        );
        setShowModal(false);
        alert('Inventory updated successfully!');
      }
    } catch (error) {
      console.error('Error updating inventory:', error);
      alert('Error updating inventory');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <Card className="p-6 shadow-lg">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">Inventory Management</h1>

        <div className="mb-4 flex gap-2">
          <TextInput placeholder="Search by Medicine Name or ID" value={search} onChange={(e) => setSearch(e.target.value)} />
          <Button onClick={() => setSearch('')}>Clear</Button>
        </div>

        <Table hoverable className="shadow-md">
          <Table.Head>
            <Table.HeadCell>ID</Table.HeadCell>
            <Table.HeadCell>Medicine Name</Table.HeadCell>
            <Table.HeadCell>Category</Table.HeadCell>
            <Table.HeadCell>Quantity Available</Table.HeadCell>
            <Table.HeadCell>Actions</Table.HeadCell>
          </Table.Head>
          <Table.Body className="divide-y">
            {filteredInventory.length > 0 ? (
              filteredInventory.map((item) => (
                <Table.Row key={item.id} className="bg-white dark:bg-gray-800">
                  <Table.Cell>{item.medicineId}</Table.Cell>
                  <Table.Cell>{item.medicineName}</Table.Cell>
                  <Table.Cell>{item.medicineCategory}</Table.Cell>
                  <Table.Cell>{item.quantityAvailable}</Table.Cell>
                  <Table.Cell>
                    <Button color="yellow" size="xs" onClick={() => openEditModal(item)}>
                      Edit
                    </Button>
                  </Table.Cell>
                </Table.Row>
              ))
            ) : (
              <Table.Row>
                <Table.Cell colSpan={5} className="text-center text-gray-500 py-4">
                  No inventory found.
                </Table.Cell>
              </Table.Row>
            )}
          </Table.Body>
        </Table>
      </Card>

      <Modal show={showModal} onClose={() => setShowModal(false)}>
        <Modal.Header>Edit Inventory</Modal.Header>
        <Modal.Body>
          {selectedMedicine && (
            <form className="space-y-4">
              <div>
                <Label htmlFor="medicineName">Medicine Name</Label>
                <TextInput id="medicineName" name="medicineName" value={selectedMedicine.medicineName} onChange={handleInputChange} />
              </div>

              <div>
                <Label htmlFor="medicineCategory">Category</Label>
                <Select id="medicineCategory" name="medicineCategory" value={selectedMedicine.medicineCategory} onChange={handleInputChange}>
                  <option value="Antibiotics">Antibiotics</option>
                  <option value="Painkillers">Painkillers</option>
                  <option value="Vitamins">Vitamins</option>
                  <option value="Antiseptics">Antiseptics</option>
                </Select>
              </div>

              <div>
                <Label htmlFor="quantityAvailable">Quantity Available</Label>
                <TextInput id="quantityAvailable" name="quantityAvailable" type="number" value={selectedMedicine.quantityAvailable} onChange={handleInputChange} />
              </div>
            </form>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button color="blue" onClick={handleUpdate} disabled={loading}>
            {loading ? 'Updating...' : 'Update'}
          </Button>
          <Button color="gray" onClick={() => setShowModal(false)}>Cancel</Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
