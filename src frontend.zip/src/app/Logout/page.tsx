'use client';

import { useState } from 'react';
import { Card, Button } from 'flowbite-react';
import { useRouter } from 'next/navigation';

export default function LogoutPage() {
  const [showModal, setShowModal] = useState(true);
  const router = useRouter();

  const handleLogout = () => {
    localStorage.removeItem('authToken'); 
    console.log('User logged out');
    setShowModal(false);
    router.push('/Login');
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      <Card className="p-6 shadow-lg w-full max-w-md text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Are you sure you want to logout?</h2>
        <div className="flex justify-center gap-4 mt-4">
          <Button color="gray" onClick={() => router.back()}>
            Cancel
          </Button>
          <Button color="red" onClick={handleLogout}>
            Logout
          </Button>
        </div>
      </Card>
    </div>
  );
}
