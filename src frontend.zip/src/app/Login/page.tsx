'use client';
import React, { useState } from "react";
import { Button, Card, TextInput } from "flowbite-react";
import { useRouter } from 'next/navigation';

export default function Login() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [error, setError] = useState('');
  const router = useRouter();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
  
    try {
      const response = await fetch('http://localhost:4002/login/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
  
      const result = await response.json();
  
      if (response.ok) {
        localStorage.setItem('authToken', result.token);

        router.push('../Dashboard');
      } else {
        setError(result.message || 'Invalid email or password. Please try again.');
      }
    } catch (error) {
      console.error('Error during login:', error);
      setError('An error occurred. Please try again.');
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 p-4">
      <Card className="w-96 shadow-2xl border border-gray-200 p-6">
        <h2 className="text-3xl font-bold text-blue-700 text-center mb-4">Welcome Back</h2>
        <p className="text-center text-gray-600 mb-6">Sign in to continue</p>
       
        <form className="flex flex-col space-y-5" onSubmit={handleSubmit}>
          <TextInput
            type="email"
            name="email"
            placeholder="Enter your email"
            required
            className="h-12 text-lg px-4 focus:ring-2 focus:ring-blue-500"
            value={formData.email}
            onChange={handleChange}
          />
          <TextInput
            type="password"
            name="password"
            placeholder="Enter your password"
            required
            className="h-12 text-lg px-4 focus:ring-2 focus:ring-blue-500"
            value={formData.password}
            onChange={handleChange}
          />
         
          <Button
            type="submit"
            gradientDuoTone="greenToBlue"
            className="w-full text-lg h-12"
          >
            Login
          </Button>
        </form>
 
        <div className="text-center mt-6">
          <p className="text-gray-600">Don't have an account?</p>
          <Button
            href="./Registration"
            gradientDuoTone="greenToBlue"
            className="w-full text-lg h-12 mt-3"
          >
            Register Now
          </Button>
        </div>
      </Card>
    </div>
  );
}