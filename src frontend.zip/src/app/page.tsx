'use client';
import React from "react";
import { Button, Card } from 'flowbite-react';

export default function Page() {
  return (
    <div>
      {/* Navbar */}
      <nav className="bg-gray-600 py-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center px-6">
          <div className="text-white text-2xl font-bold">E-Health Care Services</div>
          <div className="flex space-x-6">
            <a href="./Login" className="text-white hover:text-gray-300">Login Pharmacist</a>
            <a href="./Services" className="text-white hover:text-gray-300">Services</a>
            <a href="./Contact" className="text-white hover:text-gray-300">Contact</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section
        className="bg-cover bg-center py-32"
        style={{ backgroundImage: "url('/3.svg')" }}
      >
        <div className="container mx-auto text-center text-white">
          <h1 className="text-5xl font-extrabold text-pink-600 mb-6">
            Welcome to E-Health Care Services
          </h1>
          <p className="text-3xl text-black font-extrabold mb-20">
            Bringing healthcare to your doorstep with convenience and efficiency.
          </p>
          <div className="flex justify-center space-x-4">
            <Button href="./Services" gradientDuoTone="greenToBlue" size="lg">
              Explore Our Services
            </Button>
            <Button href="./Contact" gradientDuoTone="greenToBlue" size="lg">
              Contact Us Now
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-gray-50">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-semibold text-blue-600 mb-8">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <Card className="shadow-lg">
              <h3 className="text-xl font-semibold text-blue-600 mb-4">Telemedicine</h3>
              <p className="text-gray-600">
                Consult with doctors from the comfort of your home. Fast and easy online consultations.
              </p>
            </Card>
            <Card className="shadow-lg">
              <h3 className="text-xl font-semibold text-blue-600 mb-4">Emergency Services</h3>
              <p className="text-gray-600">
                Our team is always ready to assist with any medical emergencies. Available 24/7.
              </p>
            </Card>
            <Card className="shadow-lg">
              <h3 className="text-xl font-semibold text-blue-600 mb-4">Health Checkups</h3>
              <p className="text-gray-600">
                Regular checkups to monitor your health and catch any potential issues early.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-24 bg-blue-50">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-semibold text-blue-600 mb-8">What Our Patients Say</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <Card>
              <p className="italic text-gray-600">
                "The telemedicine service was quick and efficient. Highly recommend!"
              </p>
              <h3 className="mt-4 font-semibold text-blue-600">- Sarah J.</h3>
            </Card>
            <Card>
              <p className="italic text-gray-600">
                "Amazing team and exceptional emergency care. Thank you for being there 24/7!"
              </p>
              <h3 className="mt-4 font-semibold text-blue-600">- Michael D.</h3>
            </Card>
            <Card>
              <p className="italic text-gray-600">
                "The regular checkups have been a lifesaver for my family. Great service!"
              </p>
              <h3 className="mt-4 font-semibold text-blue-600">- Emma W.</h3>
            </Card>
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-24 bg-gray-100">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-semibold text-blue-600 mb-6">Stay Updated</h2>
          <p className="text-lg text-gray-600 mb-8">
            Subscribe to our newsletter for the latest updates and health tips.
          </p>
          <form className="flex justify-center space-x-4">
            <input
              type="email"
              placeholder="Enter your email"
              className="p-3 border rounded-lg w-1/3"
            />
            <Button type="submit" gradientDuoTone="purpleToBlue" size="lg">
              Subscribe
            </Button>
          </form>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="bg-blue-600 py-24">
        <div className="container mx-auto text-center text-white">
          <h2 className="text-3xl font-semibold mb-6">Get In Touch</h2>
          <p className="text-lg mb-8">
            Have any questions? Feel free to reach out to us anytime.
          </p>
          <Button
            href="mailto:tamasaha39@gmail.com"
            gradientDuoTone="greenToBlue"
            size="lg"
          >
            Email Us
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 py-6 text-white">
        <div className="container mx-auto text-center">
          <div className="mb-4">
            <a href="./" className="text-blue-400 hover:underline">
              Home
            </a>{" "}
            |{" "}
            <a href="./Services" className="text-blue-400 hover:underline">
              Services
            </a>{" "}
            |{" "}
            <a href="./Contact" className="text-blue-400 hover:underline">
              Contact
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
