'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, TextInput, Button, Label, Datepicker, Alert } from 'flowbite-react';

export default function CreateOrder() {
  const router = useRouter();

  const [order, setOrder] = useState({
    patientId: '',
    medicineName: '',
    quantity: '',
    price: '',
    deliveryDate: '',
    deliveryAddress: '',
    status: 'Pending',
  });

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setOrder({ ...order, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!order.patientId || !order.medicineName || !order.quantity || !order.price || !order.deliveryAddress) {
      setError('Please fill all required fields!');
      return;
    }
  
    const token = localStorage.getItem('authToken');
    if (!token) {
      setError('You are not authenticated. Please log in.');
      router.push('/login');
      return;
    }
  
    try {
      const response = await fetch('http://localhost:4002/order/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(order),
      });
  
      if (!response.ok) {
        const errorData = await response.json();
        console.error("Backend error response:", errorData);
        throw new Error(errorData.message || 'Failed to create order');
      }
  
      const data = await response.json();

      setSuccess('Order created successfully!');
      setError('');
  
      setOrder({
        patientId: '',
        medicineName: '',
        quantity: '',
        price: '',
        deliveryDate: '',
        deliveryAddress: '',
        status: 'Pending',
      });

    } catch (error) {
      console.error('Order Creation Error:', error);
      setError(error.message);
      setSuccess('');
    }
  };
  

  return (
    <div className="p-8 bg-gray-50 min-h-screen flex flex-col items-center">
      <Card className="p-6 shadow-lg w-full max-w-2xl">
        <h1 className="text-2xl font-bold mb-4 text-gray-800">Create New Order</h1>

        {error && (
          <Alert color="failure" className="mb-4">
            {error}
          </Alert>
        )}
        {success && (
          <Alert color="success" className="mb-4">
            {success}
          </Alert>
        )}

      
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label value="Patient ID" />
            <TextInput
              type="number"
              name="patientId"
              placeholder="Enter Patient ID"
              value={order.patientId}
              onChange={handleChange}
              required
            />
          </div>

          <div>
            <Label value="Medicine Name" />
            <TextInput
              type="text"
              name="medicineName"
              placeholder="Enter Medicine Name"
              value={order.medicineName}
              onChange={handleChange}
              required
            />
          </div>

          <div>
            <Label value="Quantity" />
            <TextInput
              type="number"
              name="quantity"
              placeholder="Enter Quantity"
              value={order.quantity}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <Label value="Price" />
            <TextInput
              type="number"
              step="0.01"
              name="price"
              placeholder="Enter Price"
              value={order.price}
              onChange={handleChange}
              required
            />
          </div>
          <Datepicker  name="deliveryDate"  placeholder="Select Delivery Date"  onChange={(date) => setOrder({ ...order, deliveryDate: date })} />

          <div>
            <Label value="Delivery Address" />
            <TextInput
              type="text"
              name="deliveryAddress"
              placeholder="Enter Delivery Address"
              value={order.deliveryAddress}
              onChange={handleChange}
              required
            />
          </div>
          <Button type="submit" color="green" className="w-full">
            Submit Order
          </Button>
        </form>
      </Card>
      <div className="mt-6">
        <Button color="gray" onClick={() => router.back()} className="w-32">
          ⬅ Back
        </Button>
      </div>
    </div>
  );
}