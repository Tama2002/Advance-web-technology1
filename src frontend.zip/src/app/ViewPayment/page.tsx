'use client';
import { useState, useEffect } from 'react';
import { Table, Button, TextInput, Card } from 'flowbite-react';
import axios from 'axios';
import { useRouter } from 'next/navigation';

export default function PaymentManagement() {
  const [payments, setPayments] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  
  const fetchPayments = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://localhost:4002/payment');
      setPayments(response.data.data); 
    } catch (error) {
      console.error('Failed to fetch payments:', error);
      alert('Failed to fetch payments');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPayments(); 
  }, []);

  const filteredPayments = payments.filter(
    (p) =>
      p.id.toString().includes(search) || 
      p.patientName.toLowerCase().includes(search.toLowerCase()) || 
      p.patientEmail.toLowerCase().includes(search.toLowerCase()) 
  );

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <Card className="p-6 shadow-lg">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">Payment Management</h1>

        <div className="mb-4 flex gap-2">
          <TextInput
            placeholder="Search by Payment ID, Patient Name, or Email"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <Button onClick={() => setSearch('')}>Clear</Button>
        </div>

        <Table hoverable className="shadow-md">
          <Table.Head>
            <Table.HeadCell>ID</Table.HeadCell>
            <Table.HeadCell>Patient Name</Table.HeadCell>
            <Table.HeadCell>Email</Table.HeadCell>
            <Table.HeadCell>Amount</Table.HeadCell>
            <Table.HeadCell>Method</Table.HeadCell>
            <Table.HeadCell>Date</Table.HeadCell>
          </Table.Head>
          <Table.Body className="divide-y">
            {loading ? (
              <Table.Row>
                <Table.Cell colSpan={6} className="text-center text-gray-500 py-4">
                  Loading payments...
                </Table.Cell>
              </Table.Row>
            ) : filteredPayments.length > 0 ? (
              filteredPayments.map((payment) => (
                <Table.Row key={payment.id} className="bg-white dark:bg-gray-800">
                  <Table.Cell>{payment.id}</Table.Cell>
                  <Table.Cell>{payment.patientName}</Table.Cell>
                  <Table.Cell>{payment.patientEmail}</Table.Cell>
                  <Table.Cell>${payment.amount}</Table.Cell>
                  <Table.Cell>{payment.paymentMethod}</Table.Cell>
                  <Table.Cell>{payment.paymentDate}</Table.Cell>
                </Table.Row>
              ))
            ) : (
              <Table.Row>
                <Table.Cell colSpan={6} className="text-center text-gray-500 py-4">
                  No payments found.
                </Table.Cell>
              </Table.Row>
            )}
          </Table.Body>
        </Table>

        <div className="mt-4">
          <Button color="blue" onClick={() => router.back()}>
            Back
          </Button>
        </div>
      </Card>
    </div>
  );
}
