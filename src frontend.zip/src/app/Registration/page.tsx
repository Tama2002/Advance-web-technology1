'use client';
import React, { useState } from "react";
import { Button, Card, TextInput, Alert, Select } from "flowbite-react";

export default function Register() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    name: '',
    phoneNumber: '',
    nidNumber: '',
    address: '',
    dateOfBirth: '',
    gender: '',
  });

  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  // Handle Input Change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setError("");
  };

  // Form Submit Handler
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Check if passwords match
    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match!");
      return;
    }

    try {
      const response = await fetch('http://localhost:4002/login/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (response.ok) {
        setSuccessMessage("Registration successful! Confirmation email sent.");
        setFormData({
          email: '',
          password: '',
          confirmPassword: '',
          name: '',
          phoneNumber: '',
          nidNumber: '',
          address: '',
          dateOfBirth: '',
          gender: '',
        });
      } else {
        setError(result.message || "Registration failed. Please try again.");
      }
    } catch (error) {
      console.error('Error:', error);
      setError("An error occurred. Please try again.");
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-purple-500 to-blue-600 p-4">
      <Card className="w-96 shadow-2xl border border-gray-200 p-6">
        <h2 className="text-3xl font-bold text-blue-700 text-center mb-4">Create an Account</h2>
        <p className="text-center text-gray-600 mb-6">Sign up to get started</p>

        <form onSubmit={handleSubmit} className="flex flex-col space-y-4">
          <TextInput
            type="text"
            name="name"
            placeholder="Full Name"
            required
            value={formData.name}
            onChange={handleChange}
            className="h-12 text-lg px-4"
          />
          <TextInput
            type="email"
            name="email"
            placeholder="Email Address"
            required
            value={formData.email}
            onChange={handleChange}
            className="h-12 text-lg px-4"
          />
          <TextInput
            type="password"
            name="password"
            placeholder="Password"
            required
            value={formData.password}
            onChange={handleChange}
            className="h-12 text-lg px-4"
          />
          <TextInput
            type="password"
            name="confirmPassword"
            placeholder="Confirm Password"
            required
            value={formData.confirmPassword}
            onChange={handleChange}
            className="h-12 text-lg px-4"
          />
          <TextInput
            type="text"
            name="nidNumber"
            placeholder="National ID (NID)"
            required
            value={formData.nidNumber}
            onChange={handleChange}
            className="h-12 text-lg px-4"
          />
          <TextInput
            type="string"
            name="address"
            placeholder="address"
            value={formData.address}
            onChange={handleChange}
            className="h-12 text-lg px-4"
          />
          <TextInput
            type="tel"
            name="phoneNumber"
            placeholder="Phone Number"
            value={formData.phoneNumber}
            onChange={handleChange}
            className="h-12 text-lg px-4"
          />
          <TextInput
            type="date"
            name="dateOfBirth"
            placeholder="dateOfBirth"
            value={formData.dateOfBirth}
            onChange={handleChange}
            className="h-12 text-lg px-4"
          />
          <Select name="gender" required value={formData.gender} onChange={handleChange}>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </Select>

          {error && <Alert color="failure">{error}</Alert>}
          {successMessage && <Alert color="success">{successMessage}</Alert>}

          <Button type="submit" gradientDuoTone="greenToBlue" className="w-full text-lg h-12">
            Register
          </Button>
        </form>

        <div className="flex justify-between items-center mt-6">
          <Button href="./Login" gradientDuoTone="greenToBlue" className="text-lg h-12">
            Back to Login
          </Button>
          <p className="text-gray-600 text-sm">
            Already have an account? <a href="./Login" className="text-blue-500 hover:underline">Login</a>
          </p>
        </div>
      </Card>
    </div>
  );
}