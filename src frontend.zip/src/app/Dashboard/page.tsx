'use client';
import { useState, useEffect } from 'react';
import { Avatar, Navbar } from 'flowbite-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function DashboardPage() {
  const [user, setUser] = useState({
    name: '',
    email: '',
    password: '',
    phoneNumber: '',
    address: '',
    nidNumber: '',
    dateOfBirth: '',
    gender: ''
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const router = useRouter();

  useEffect(() => {
    const fetchUserData = async () => {
      const token = localStorage.getItem('authToken');
      if (!token) {
        router.push('/Login');
        return;
      }

      try {
        const response = await fetch('http://localhost:4002/login/me', {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (!response.ok) throw new Error('Failed to fetch user data');

        const data = await response.json();
        if (data.data) {
          setUser(data.data);
        } else {
          setUser(data);
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        localStorage.removeItem('authToken');
        router.push('/Login');
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    router.push('/Login');
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  return (
    <div className="min-h-screen flex flex-col bg-white text-purple-800">
      <Navbar className="bg-purple-700 text-white">
        <Navbar.Brand href="#" className="text-white font-bold text-xl">
          E-Health Care Pharmacist Portal
        </Navbar.Brand>
        <div className="flex-grow" />
        <div className="flex items-center space-x-4">
          <Avatar
            rounded={true}
            size="md"
            placeholderInitials={user.name[0] || ''}
          />
          <button
          
            onClick={handleLogout}
            className="text-white hover:bg-purple-800 px-4 py-2 rounded-lg"
          >
            Logout
          </button>
        </div>
      </Navbar>

      <div className="flex flex-1">
        <aside className="w-64 bg-purple-800 text-white flex flex-col p-6">
          <div className="flex items-center space-x-4 mb-6">
            <Avatar
              rounded={true}
              size="lg"
              placeholderInitials={user.name[0] || ''}
            />
            <div>
              <p className="text-xl font-bold">{user.name}</p>
              <p className="text-sm">{user.email}</p>
            </div>
          </div>
          <nav className="flex-1 space-y-4">
            <Link href="../Prescription" className="block py-2 px-4 rounded-lg hover:bg-purple-900">
              View Prescription
            </Link>
            <Link href="../Order" className="block py-2 px-4 rounded-lg hover:bg-purple-900">
              Order
            </Link>
            <Link href="../ProcessOrder" className="block py-2 px-4 rounded-lg hover:bg-purple-900">
              Process Order
            </Link>
            <Link href="../Management" className="block py-2 px-4 rounded-lg hover:bg-purple-900">
              Inventory Management
            </Link>
            <Link href="../UpdateStock" className="block py-2 px-4 rounded-lg hover:bg-purple-900">
              Update Stock
            </Link>
            <Link href="../Payment" className="block py-2 px-4 rounded-lg hover:bg-purple-900">
              Payment
            </Link>
            <Link href="../ViewPayment" className="block py-2 px-4 rounded-lg hover:bg-purple-900">
              View All Payments
            </Link>
            <Link href="../Logout" className="block py-2 px-4 rounded-lg hover:bg-purple-900">
              Logout
            </Link>
          </nav>
        </aside>

        <main className="flex-1 p-8">
          <div className="bg-white shadow-lg rounded-lg p-6">
            <h1 className="text-2xl font-bold text-purple-800 mb-4">
              Welcome, {user.name}!
            </h1>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <p className="font-semibold">Email:</p>
                <p>{user.email}</p>
              </div>
              <div>
                <p className="font-semibold">Phone:</p>
                <p>{user.phoneNumber || 'N/A'}</p>
              </div>
              <div>
                <p className="font-semibold">Address:</p>
                <p>{user.address || 'N/A'}</p>
              </div>
              <div>
                <p className="font-semibold">National ID Number:</p>
                <p>{user.nidNumber || 'N/A'}</p>
              </div>
              <div>
                <p className="font-semibold">Gender:</p>
                <p>{user.gender || 'N/A'}</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            {/* Keep your existing dashboard cards here */}
          </div>
        </main>
      </div>
    </div>
  );
}
