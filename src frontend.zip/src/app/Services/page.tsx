"use client";
import React from "react";
import { Card, Button } from "flowbite-react";
import { useRouter } from "next/navigation";
import { FaUserMd, FaAmbulance, FaHeartbeat, FaArrowLeft } from "react-icons/fa";

const services = [
  { icon: <FaUserMd className="text-blue-600 text-5xl" aria-label="Telemedicine Icon" />, title: "Telemedicine", color: "text-blue-700", text: "Consult with doctors from the comfort of your home. Fast and easy online consultations." },
  { icon: <FaAmbulance className="text-red-600 text-5xl" aria-label="Emergency Icon" />, title: "Emergency Services", color: "text-red-700", text: "Our team is always ready to assist with any medical emergencies. Available 24/7." },
  { icon: <FaHeartbeat className="text-green-600 text-5xl" aria-label="Health Checkup Icon" />, title: "Health Checkups", color: "text-green-700", text: "Regular checkups to monitor your health and catch any potential issues early." }
];

export default function Services() {
  const router = useRouter();

  return (
    <section
      className="min-h-screen bg-cover bg-center bg-fixed flex flex-col items-center justify-center"
      style={{ backgroundImage: "url('/3.svg')" }}
    >
      <div className="bg-white bg-opacity-80 backdrop-blur-md min-h-screen w-full flex flex-col justify-center py-24">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold text-blue-700 mb-8">Our Services</h2>
          <p className="text-lg text-gray-600 mb-12">Providing high-quality healthcare at your fingertips.</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {services.map((service, index) => (
              <Card key={index} className="shadow-xl transform transition duration-300 hover:scale-105 hover:shadow-2xl">
                <div className="flex justify-center mb-4">{service.icon}</div>
                <h3 className={`text-2xl font-semibold ${service.color} mb-4`}>{service.title}</h3>
                <p className="text-gray-700">{service.text}</p>
              </Card>
            ))}
          </div>
        </div>

        <div className="container mx-auto mt-12 flex justify-start">
          <Button onClick={() => router.back()} gradientDuoTone="bluetoblack" size="lg" className="flex items-center">
            <FaArrowLeft className="mr-2" /> Back
          </Button>
        </div>
      </div>
    </section>
  );
}
