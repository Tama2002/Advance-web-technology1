

'use client';

import { useState, useEffect } from 'react';
import { Table, Button, Select, Card } from 'flowbite-react';
import { useRouter } from 'next/navigation';

export default function ProcessOrder() {
  const router = useRouter();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch all orders
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await fetch('http://localhost:4002/order');
        if (!response.ok) throw new Error('Failed to fetch orders');
        const data = await response.json();
        setOrders(data.data);
      } catch (error) {
        console.error('Error fetching orders:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  // Update order status
  const updateOrderStatus = async (id, newStatus) => {
    try {
      const response = await fetch(`http://localhost:4002/order/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: newStatus }),
      });
      if (!response.ok) throw new Error('Failed to update order status');
      const updatedOrder = await response.json();

      // Update state with new status
      setOrders((prevOrders) =>
        prevOrders.map((order) =>
          order.id === id ? { ...order, status: newStatus } : order
        )
      );
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <Card className="p-6 shadow-lg">
        <h1 className="text-2xl font-bold mb-4 text-gray-800">Process Orders</h1>

        {/* Orders Table */}
        <Table hoverable className="shadow-md">
          <Table.Head>
            <Table.HeadCell>ID</Table.HeadCell>
            <Table.HeadCell>Patient ID</Table.HeadCell>
            <Table.HeadCell>Medicine Name</Table.HeadCell>
            <Table.HeadCell>Quantity</Table.HeadCell>
            <Table.HeadCell>Price</Table.HeadCell>
            <Table.HeadCell>Order Date</Table.HeadCell>
            <Table.HeadCell>Delivery Date</Table.HeadCell>
            <Table.HeadCell>Status</Table.HeadCell>
            <Table.HeadCell>Action</Table.HeadCell>
          </Table.Head>
          <Table.Body className="divide-y">
            {loading ? (
              <Table.Row>
                <Table.Cell colSpan={8} className="text-center py-4">Loading...</Table.Cell>
              </Table.Row>
            ) : orders.length > 0 ? (
              orders.map((order) => (
                <Table.Row key={order.id}>
                  <Table.Cell>{order.id}</Table.Cell>
                  <Table.Cell>{order.patientId}</Table.Cell>
                  <Table.Cell>{order.medicineName}</Table.Cell>
                  <Table.Cell>{order.quantity}</Table.Cell>
                  <Table.Cell>TK{parseFloat(order.price).toFixed(2)}</Table.Cell>
                  <Table.Cell>{order.orderDate}</Table.Cell>
                  <Table.Cell>{order.deliveryDate}</Table.Cell>
                  <Table.Cell>
                    <Select
                      value={order.status}
                      onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                      className="text-sm"
                    >
                      <option value="Pending">Pending</option>
                      <option value="Shipped">Shipped</option>
                      <option value="Delivered">Delivered</option>
                      <option value="Cancelled">Cancelled</option>
                    </Select>
                  </Table.Cell>
                  <Table.Cell>
                    <Button
                      color="blue"
                      size="xs"
                      onClick={() => alert(`Order ID: ${order.id}\nDetails: ${order.medicineName} - ${order.quantity} pcs`)}
                    >
                      View Details
                    </Button>
                  </Table.Cell>
                </Table.Row>
              ))
            ) : (
              <Table.Row>
                <Table.Cell colSpan={8} className="text-center text-gray-500 py-4">No orders found.</Table.Cell>
              </Table.Row>
            )}
          </Table.Body>
        </Table>
      </Card>
      <div className="mt-6">
        <Button color="gray" onClick={() => router.back()} className="w-32">
          ⬅ Back
        </Button>
      </div>
    </div>
  );
}
