'use client';

import { useState } from 'react';
import { TextInput, Button, Card, Label } from 'flowbite-react';
import axios from 'axios';

export default function CreateInventory() {
  const [inventory, setInventory] = useState({
    medicineId: '',
    medicineName: '',
    medicineCategory: '',
    quantityAvailable: '',
  });

  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleChange = (e) => {
    setInventory({
      ...inventory,
      [e.target.name]: e.target.value,
    });
  };

  // Handle Form Submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!inventory.medicineId || !inventory.medicineName || !inventory.medicineCategory || !inventory.quantityAvailable) {
      alert('Please fill all fields.');
      return;
    }

    try {
      const response = await axios.post('http://localhost:4002/inventory/create', inventory, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('authToken')}`, // Assuming you store token in localStorage
        },
      });

      if (response.status === 201) {
        setSuccessMessage(`Medicine "${inventory.medicineName}" added successfully!`);
        setErrorMessage('');
      } else {
        setErrorMessage('Failed to add medicine.');
      }
    } catch (error) {
      console.error('Error adding medicine:', error);
      setErrorMessage('An error occurred while adding the medicine.');
    }

    
    setInventory({
      medicineId: '',
      medicineName: '',
      medicineCategory: '',
      quantityAvailable: '',
    });

    setTimeout(() => setSuccessMessage(''), 3000);
  };

  return (
    <div className="p-8 bg-gray-50 min-h-screen flex justify-center items-center">
      <Card className="w-full max-w-lg p-6 shadow-lg">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">Add New Medicine</h1>

        {successMessage && <p className="text-green-600 text-sm mb-4">{successMessage}</p>}
        {errorMessage && <p className="text-red-600 text-sm mb-4">{errorMessage}</p>}

        <form onSubmit={handleSubmit} className="space-y-4">
          
          <div>
            <Label htmlFor="medicineId">Medicine ID</Label>
            <TextInput
              id="medicineId"
              name="medicineId"
              value={inventory.medicineId}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <Label htmlFor="medicineName">Medicine Name</Label>
            <TextInput
              id="medicineName"
              name="medicineName"
              value={inventory.medicineName}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <Label htmlFor="medicineCategory">Medicine Category</Label>
            <TextInput
              id="medicineCategory"
              name="medicineCategory"
              value={inventory.medicineCategory}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <Label htmlFor="quantityAvailable">Quantity Available</Label>
            <TextInput
              id="quantityAvailable"
              name="quantityAvailable"
              type="number"
              value={inventory.quantityAvailable}
              onChange={handleChange}
              required
            />
          </div>
          <div className="flex justify-between">
            <Button
              type="button"
              onClick={() => window.history.back()}
              className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg"
            >
              Back
            </Button>
            <Button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg"
            >
              Add Medicine
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
