import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LoginModule } from './login/login.module';
import { Login } from './login/login.entity';
import { InventoryModule } from './inventory/inventory.module';
import { PaymentModule } from './payment/payment.module';
import { Payment } from './payment/payment.entity';
import { Inventory } from './inventory/inventory.entity';
import { AuthModule } from './auth/auth.module';
import { OrderModule } from './order/order.module';
import { Order } from './order/order.entity';
import { Prescription } from './prescription/prescription.entity';
import { PrescriptionModule } from './prescription/prescription.module';
@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'postgres',
      password: 'tama',
      database: 'pharmacist',
      entities: [Login, Payment, Inventory, Order, Prescription],
      synchronize: true,
    }),
    LoginModule,
    InventoryModule,
    PaymentModule,
    AuthModule,
    OrderModule,
    PrescriptionModule,
 
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
