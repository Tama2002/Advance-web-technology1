import {
    Controller,
    Post,
    Get,
    Param,
    Body,
    HttpException,
    HttpStatus,
    Patch,
  } from '@nestjs/common';
  import { OrderService } from './order.service';
  import { Order } from './order.entity';
  
  @Controller('order')
  export class OrderController {
    constructor(private readonly orderService: OrderService) {}
  
    @Post('create')
    async createOrder(@Body() orderData: Partial<Order>) {
      try {
        const createdOrder = await this.orderService.createOrder(orderData);
        return {
          message: 'Order created successfully',
          data: createdOrder,
        };
      } catch (error) {
        console.error('Order Creation Error:', error);
        throw new HttpException(
          'Failed to create order',
          HttpStatus.BAD_REQUEST,
        );
      }
    }
  
    @Get(':id')
    async getOrderById(@Param('id') id: number) {
      try {
        const order = await this.orderService.getOrderById(id);
        if (!order) {
          throw new HttpException('Order not found', HttpStatus.NOT_FOUND);
        }
        return {
          message: 'Order retrieved successfully',
          data: order,
        };
      } catch (error) {
        console.error('Get Order Error:', error);
        throw error;
      }
    }
  
    @Get()
    async getAllOrders() {
      try {
        const orders = await this.orderService.getAllOrders();
        return {
          message: 'Orders retrieved successfully',
          data: orders,
        };
      } catch (error) {
        console.error('Get Orders Error:', error);
        throw new HttpException(
          'Failed to fetch orders',
          HttpStatus.BAD_REQUEST,
        );
      }
    }
    @Patch(':id')
async updateOrderStatus(@Param('id') id: number, @Body() body: { status: string }) {
  try {
    const updatedOrder = await this.orderService.updateOrderStatus(id, body.status);
    if (!updatedOrder) {
      throw new HttpException('Order not found', HttpStatus.NOT_FOUND);
    }
    return {
      message: 'Order status updated successfully',
      data: updatedOrder,
    };
  } catch (error) {
    console.error('Update Order Status Error:', error);
    throw new HttpException('Failed to update order status', HttpStatus.BAD_REQUEST);
  }
}
  }
  