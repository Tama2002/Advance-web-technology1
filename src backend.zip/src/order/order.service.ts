import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Order } from './order.entity';

@Injectable()
export class OrderService {
  constructor(
    @InjectRepository(Order)
    private readonly orderRepo: Repository<Order>,
  ) {}

  async createOrder(orderData: Partial<Order>): Promise<Order> {
    const newOrder = this.orderRepo.create(orderData);
    return this.orderRepo.save(newOrder);
  }

  async getOrderById(id: number): Promise<Order | null> {
    return this.orderRepo.findOne({ where: { id } });
  }

  async getAllOrders(): Promise<Order[]> {
    return this.orderRepo.find();
  }
  async updateOrderStatus(id: number, status: string): Promise<Order | null> {
    const order = await this.orderRepo.findOne({ where: { id } });
    if (!order) return null;
  
    order.status = status;
    return this.orderRepo.save(order);
  }
}