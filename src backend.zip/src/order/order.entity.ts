import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

 
@Entity()
export class Order {
  @PrimaryGeneratedColumn()
  id: number;
 
 
  @Column()
  patientId: number;
 
 
  @Column()
  medicineName: string;
 
  @Column()
  quantity: number;
 
  @Column('decimal', { precision: 10, scale: 2 })
  price: number;
 
  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  orderDate: Date;
 
  @Column({ type: 'date', nullable: true })
  deliveryDate: Date;
 
  @Column()
  deliveryAddress: string;

  @Column()
  status: string;
}