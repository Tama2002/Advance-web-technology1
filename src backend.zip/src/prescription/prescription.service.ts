import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Prescription } from './prescription.entity';
import { Repository } from 'typeorm';

@Injectable()
export class PrescriptionService {
  constructor(
    @InjectRepository(Prescription)
    private readonly prescriptionRepo: Repository<Prescription>,
  ) {}

  async createPrescription(prescriptionData: Partial<Prescription>): Promise<Prescription> {
    const newPrescription = this.prescriptionRepo.create(prescriptionData);
    return this.prescriptionRepo.save(newPrescription);
  }

  async getPrescriptionById(id: number): Promise<Prescription | null> {
    return this.prescriptionRepo.findOne({ where: { id } });
  }
  
  async getAllPrescriptions(): Promise<Prescription[]> {
    return this.prescriptionRepo.find(); // Fetch all prescriptions
  }
}
