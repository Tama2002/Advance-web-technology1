import {
    Controller,
    Post,
    Get,
    Param,
    Body,
    HttpException,
    HttpStatus,
    Query,
    UseGuards,
  } from '@nestjs/common';
  import { PrescriptionService } from './prescription.service';
  import { Prescription } from './prescription.entity';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
  
  @Controller('prescription')
  export class PrescriptionController {
    constructor(private readonly prescriptionService: PrescriptionService) {}
  
    @Post('create')
    async createPrescription(@Body() prescriptionData: Partial<Prescription>) {
      try {
        const createdPrescription = await this.prescriptionService.createPrescription(prescriptionData);
        return {
          message: 'Prescription created successfully',
          data: createdPrescription,
        };
      } catch (error) {
        console.error('Prescription Creation Error:', error);
        throw new HttpException(
          'Failed to create prescription',
          HttpStatus.BAD_REQUEST,
        );
      }
    }
  
    @Get(':id')
    async getPrescriptionById(@Param('id') id: number) {
      try {
        const prescription = await this.prescriptionService.getPrescriptionById(id);
        if (!prescription) {
          throw new HttpException('Prescription not found', HttpStatus.NOT_FOUND);
        }
        return {
          message: 'Prescription retrieved successfully',
          data: prescription,
        };
      } catch (error) {
        console.error('Get Prescription Error:', error);
        throw error;
      }
    }
    @UseGuards(JwtAuthGuard) // Ensure only authenticated users can access this endpoint
    @Get()
    async getAllPrescriptions() {
      try {
        const prescriptions = await this.prescriptionService.getAllPrescriptions();
        return {
          message: 'Prescriptions retrieved successfully',
          data: prescriptions,
        };
      } catch (error) {
        console.error('Get Prescriptions Error:', error);
        throw new HttpException(
          'Failed to fetch prescriptions',
          HttpStatus.BAD_REQUEST,
        );
      }
}
  }
  