import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Inventory } from './inventory.entity';

@Injectable()
export class InventoryService {
  constructor(
    @InjectRepository(Inventory)
    private readonly inventoryRepo: Repository<Inventory>,
  ) {}

  async createInventory(inventoryData: Partial<Inventory>): Promise<Inventory> {
    const newInventory = this.inventoryRepo.create(inventoryData);
    return this.inventoryRepo.save(newInventory);
  }

  async getAllInventory(): Promise<Inventory[]> {
    return this.inventoryRepo.find();
  }

  async getInventoryById(id: number): Promise<Inventory | null> {
    return this.inventoryRepo.findOne({ where: { id } });
  }

  async updateInventoryById(id: number, inventoryData: Partial<Inventory>): Promise<Inventory | null> {
    const inventoryItem = await this.getInventoryById(id);
    if (!inventoryItem) {
      return null;
    }
    Object.assign(inventoryItem, inventoryData);
    return this.inventoryRepo.save(inventoryItem);
  }

  async deleteInventoryById(id: number): Promise<boolean> {
    const result = await this.inventoryRepo.delete(id);
    return result.affected > 0;
  }
}
