import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export class Inventory {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  medicineId: string;

  @Column()
  medicineName: string;

  @Column()
  medicineCategory: string;

  @Column("int")
  quantityAvailable: number;
}
