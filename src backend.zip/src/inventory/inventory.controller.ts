import { Controller, Post, Get, Put, Delete, Body, Param, HttpException, HttpStatus } from '@nestjs/common';
import { InventoryService } from './inventory.service';
import { Inventory } from './inventory.entity';

@Controller('inventory')
export class InventoryController {
  constructor(private readonly inventoryService: InventoryService) {}

  @Post('create')
  async createInventory(@Body() inventoryData: Partial<Inventory>) {
    try {
      const createdInventory = await this.inventoryService.createInventory(inventoryData);
      return {
        message: 'Inventory item created successfully',
        data: createdInventory,
      };
    } catch (error) {
      console.error('Inventory Creation Error:', error);
      throw new HttpException('Failed to create inventory item', HttpStatus.BAD_REQUEST);
    }
  }

  @Get()
  async getAllInventory() {
    try {
      const inventoryList = await this.inventoryService.getAllInventory();
      return {
        message: 'Inventory retrieved successfully',
        data: inventoryList,
      };
    } catch (error) {
      console.error('Get Inventory Error:', error);
      throw new HttpException('Failed to fetch inventory items', HttpStatus.BAD_REQUEST);
    }
  }

  @Get(':id')
  async getInventoryById(@Param('id') id: number) {
    try {
      const inventoryItem = await this.inventoryService.getInventoryById(id);
      if (!inventoryItem) {
        throw new HttpException('Inventory item not found', HttpStatus.NOT_FOUND);
      }
      return {
        message: 'Inventory item retrieved successfully',
        data: inventoryItem,
      };
    } catch (error) {
      console.error('Get Inventory Item Error:', error);
      throw error;
    }
  }

  @Put('update/:id')
  async updateInventoryById(@Param('id') id: number, @Body() inventoryData: Partial<Inventory>) {
    try {
      const updatedInventory = await this.inventoryService.updateInventoryById(id, inventoryData);
      if (!updatedInventory) {
        throw new HttpException('Inventory item not found', HttpStatus.NOT_FOUND);
      }
      return {
        message: 'Inventory item updated successfully',
        data: updatedInventory,
      };
    } catch (error) {
      console.error('Update Inventory Error:', error);
      throw error;
    }
  }

  @Delete('delete/:id')
  async deleteInventoryById(@Param('id') id: number) {
    try {
      const deleted = await this.inventoryService.deleteInventoryById(id);
      if (!deleted) {
        throw new HttpException('Inventory item not found', HttpStatus.NOT_FOUND);
      }
      return { message: 'Inventory item deleted successfully' };
    } catch (error) {
      console.error('Delete Inventory Error:', error);
      throw error;
    }
  }
}
