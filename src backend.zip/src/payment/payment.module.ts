import { Module } from '@nestjs/common';
import { PaymentController } from './payment.controller';
import { PaymentService } from './payment.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Payment } from './payment.entity';
import { JwtModule } from '@nestjs/jwt';
@Module({
  imports: [TypeOrmModule.forFeature([Payment]),
  JwtModule.register({
    secret: 'your-secret-key',
    signOptions: { expiresIn: '1h' },
  }),
],
  controllers: [PaymentController],
  providers: [PaymentService]
})
export class PaymentModule {}
