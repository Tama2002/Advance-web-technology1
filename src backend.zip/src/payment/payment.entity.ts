import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
 
@Entity()
export class Payment {
  @PrimaryGeneratedColumn()
  id: number;
 
  @Column()
  patientId: number;
 
  @Column()
  patientName: string;
 
  @Column()
  patientEmail: string;
 
  @Column('decimal', { precision: 10, scale: 2 })
  amount: number;
 
  @Column({ nullable: true })
  paymentMethod?: string;
 
 
  @Column()
  paymentDate: string;
}